the Rowwise_1d.c under folder “matrix “and laplace_seq.c under folder “laplace” are provided by teacher

the Blockwise_2d.c under folder “matrix” and laplace_par_2.c under folder “laplace” is written as task implementations by Ye Cai.

run the programs like 
./example
mpirun -n 2 ./example
mpirun -n 4 ./example 
mpirun -n 8 ./example